package org.wso2.identity.esb.kerberos;

/**
 * Created by pavithra on 6/3/15.
 */
import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.context.ConfigurationContextFactory;
import org.apache.neethi.Policy;
import org.apache.neethi.PolicyEngine;
import org.apache.rampart.RampartMessageData;

public class KerberosClient implements Runnable {
    final static String RELYING_PARTY_SERVICE_EPR = "https://localhost:9444/services/echo";
    final static String ACTION_REQUEST_DATA = "request";
    final static String ACTION_PUBLISH_DATA = "publish";

    private static ConfigurationContext confContext = null;
    private static Policy servicePolicy = null;

    private int index = 0;

    public KerberosClient(int j){
        index = j;
    }

    public static void main(String[] args) throws Exception {
        String trustStore = null;
        //Import Identity Server public certificate to this key store
        trustStore = "/home/pavithra/Products/IS/5.0.0/wso2is-5.0.0/repository/resources/security/wso2carbon.jks";
        System.setProperty("javax.net.ssl.trustStore", trustStore);
        System.setProperty("javax.net.ssl.trustStorePassword", "wso2carbon");

        //Create configuration context
        confContext = ConfigurationContextFactory.createConfigurationContextFromFileSystem("repo", "repo/conf/client.axis2.xml");

        servicePolicy = loadServicePolicy("repo/conf/policy-1.xml");

        ServiceClient client = null;
        try{
            client = new ServiceClient(confContext, null);

            Options options = new Options();

            //Request data
            options.setTo(new EndpointReference(RELYING_PARTY_SERVICE_EPR));
            options.setProperty(RampartMessageData.KEY_RAMPART_POLICY, servicePolicy);

            client.setOptions(options);
            client.engageModule("addressing");
            client.engageModule("rampart");

            String value = "Hello Pavithra !!!!!!";

            System.out.println("Calling service with parameter 1 - " + value);

            OMElement response = client.sendReceive(getPayload(value));
            System.out.println("The response is : " + response);

        } catch (AxisFault axisFault){
            axisFault.printStackTrace();
            System.out.println("Could not create service client");
        }

    }

    private static Policy loadServicePolicy(String xmlPath) throws Exception {
        StAXOMBuilder builder = null;
        Policy policy = null;

        builder = new StAXOMBuilder(xmlPath);
        policy = PolicyEngine.getPolicy(builder.getDocumentElement());

        return policy;
    }

    private static OMElement getPayload(String value1) {
        OMFactory factory = OMAbstractFactory.getOMFactory();
        OMNamespace ns = factory.createOMNamespace("http://echo.services.core.carbon.wso2.org","p");
        OMElement elem = factory.createOMElement("echoString", ns);
        OMElement childElem = factory.createOMElement("in", null);
        childElem.setText(value1);
        elem.addChild(childElem);
        return elem;
    }

    public void run(){}
}
