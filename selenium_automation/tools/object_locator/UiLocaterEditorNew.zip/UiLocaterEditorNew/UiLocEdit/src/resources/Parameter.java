package resources;

/**
 * The Class Parameter.
 */
public class Parameter extends NamedEntityBase {

    /** The value. */
    private String value;

    /** The resolved value. */
    private String resolvedValue;

    /** The selenium resolved value. */
    private String seleniumResolvedValue;

    /**
     * Instantiates a new parameter.
     * 
     * @param pname
     *            the name
     * @param ptype
     *            the type
     */
    public Parameter(final String pname) {
        super(pname);

    }

    /**
     * Copy constructor
     * 
     * @param p
     */
    public Parameter(Parameter p) {
        this.name = p.getName();
        this.value = p.getValue();
        this.resolvedValue = p.getResolvedValue();
        this.seleniumResolvedValue = p.getSeleniumResolvedValue();
    }

    /**
     * Gets parameter name.
     * 
     * @return parameter name.
     */
    @Override
    public final String getName() {
        return this.name;
    }

    /**
     * Gets the name without at.
     * 
     * @return the name without at
     */
    public final String getNameWithoutAt() {
        return getName().substring(1);
    }

    /**
     * Sets the value.
     * 
     * @param pvalue
     *            the new value
     */
    public final void setValue(final String pvalue) {
        this.value = pvalue;
    }

    /**
     * Gets the value.
     * 
     * @return the value
     */
    public final String getValue() {
        return value;
    }

    /**
     * Gets the value.
     * 
     * @return the value
     */
    public final String getDoubleQuoteResolvedValue() {
        if (value.contains("\"")) {
            // LOGGER.info("There are double quotes in the locator");
            return value.replace("\"", "\\\"");
        } else {
            return value;
        }

    }

    /**
     * Gets the global var value.
     * 
     * @return the global var value
     */
    public final String getGlobalVarValue() {
        // a global variable is in script prefixed with a #
        if (value.startsWith("#")) {
            return value.substring(1);
        }
        return value;
    }

    /**
     * Sets the resolved value.
     * 
     * @param presolvedValue
     *            the new resolved value
     */
    public final void setResolvedValue(final String presolvedValue) {
        this.resolvedValue = presolvedValue;
    }

    /**
     * Gets the resolved value.
     * 
     * @return the resolved value
     */
    public final String getResolvedValue() {
        return resolvedValue;
    }

    /*
     * public String getResolvedValueQTP() { if (value.startsWith("@")) return
     * "dataValue(iterator, \"" + resolvedValue + "\")";
     * 
     * return resolvedValue; }
     */
    /**
     * Sets the selenium resolved value.
     * 
     * @param pseleniumResolvedValue
     *            the new selenium resolved value
     */
    public final void setSeleniumResolvedValue(
            final String pseleniumResolvedValue) {
        this.seleniumResolvedValue = pseleniumResolvedValue;
    }

    /**
     * Gets the selenium resolved value.
     * 
     * @return the selenium resolved value
     */
    public final String getSeleniumResolvedValue() {
        return seleniumResolvedValue;
    }

    public final String getCSharpResolvedValue() {

        String[] splittedLocator = value.split("\\.");
        String resolvedForCSharap =
                splittedLocator[0] + ".Element." + splittedLocator[1];

        return resolvedForCSharap;
    }

    public final boolean isObjectParameter() {

        if (name.equals("object")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Gets the monkey talk resolved value.
     * 
     * @return the monkey talk resolved value
     */
    public final String getMonkeyTalkResolvedValue() {
        if ("object".equalsIgnoreCase(name)) {
            return "";
        } else {
            return getResolvedValue();
        }
    }

    /**
     * Checks if is modified.
     * 
     * @return true, if is modified
     */
    @Override
    public final boolean isModified() {
        return modified;
    }

    /**
     * Sets the modified.
     * 
     * @param pmodified
     *            the new modified
     */
    @Override
    public final void setModified(final boolean pmodified) {
        modified = pmodified;
    }

    /**
     * Sets the name.
     * 
     * @param pname
     *            the new name
     */
    @Override
    public final void setName(final String pname) {
        if (this.name != null && this.name.equals(pname)) {
            return;
        }
        this.name = pname;
        modified = true;
    }

    /**
     * Gets the description.
     * 
     * @return the description
     */
    public final String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     * 
     * @param pdescription
     *            the new description
     */
    public final void setDescription(final String pdescription) {
        if (this.description != null && this.description.equals(pdescription)) {
            return;
        }
        this.description = pdescription;
        modified = true;
    }

    /**
     * Override the default toString() method. Returns the name of the entity
     * only.
     * 
     * @return name
     */
    @Override
    public final String toString() {
        return name;
    }

    /**
     * Get Entity name.
     * 
     * @return the entity
     */
    @Override
    public final String getEntity() {
        return "Parameter";
    }

    @Override
    public String getPascalName() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getCamelName() {
        // TODO Auto-generated method stub
        return null;
    }

}
