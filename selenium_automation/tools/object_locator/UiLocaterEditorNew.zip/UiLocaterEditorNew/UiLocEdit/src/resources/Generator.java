package resources;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.HashMap;

import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateGroup;

public class Generator {

    public static void createContent(final String varName,
            final Object objectToPass, final StringReader reader,
            final String targetLocation) throws Exception {
        HashMap<String, Object> map = new HashMap<String, Object>();

        map.put(varName, objectToPass);

        StringTemplateGroup group = new StringTemplateGroup(reader);

        StringTemplate fileNameTemplate = group.getInstanceOf("FileName");

        fileNameTemplate.setAttributes(map);

        String outputFileName =
                fileNameTemplate.toString().replace("/", File.separator);
        if (outputFileName == null || outputFileName.length() == 0) {
            return;
        }

        // Prepend the root folder to the output file name returned by the
        // template
        outputFileName = targetLocation + File.separator + outputFileName;

        StringTemplate contentTemplate = group.getInstanceOf("Content");
        contentTemplate.setAttributes(map);

        String outputContent = null;
        try {
            outputContent = contentTemplate.toString();
        } catch (IllegalArgumentException e) {
            String msg = e.getMessage();
            if (msg.startsWith("Can't find template")) {

                String newmsg =
                        msg.substring(("Can't find template").length(),
                                msg.indexOf(".st;"));

                throw new Exception("Error writing file " + outputFileName
                        + ": Command '" + newmsg + "' not supported!", e);
                // java.lang.IllegalArgumentException: Can't find template
                // Retrieve.st; context is [Content BusinessComponent
                // else_subtemplate TestCommand
                // if(testCommand.specialCommand)_subtemplate]; group hierarchy
                // is [Library]
            } else {
                throw new Exception("Error writing file " + outputFileName, e);
            }
        }

        String folderName =
                outputFileName.substring(0, outputFileName.lastIndexOf('.')); // strip
        // the
        // text
        folderName =
                folderName.substring(0, folderName.lastIndexOf(File.separator)); // strip
        // the
        // filename

        if (folderName != null) {
            File folder = new File(folderName);
            if (!folder.exists() && !folder.mkdirs()) {
                throw new Exception(
                        "File"
                                + folder.getName()
                                + " could not be created \n  Please check if location is read only");

            }
        }

        FileWriter out = null;
        try {
            out = new FileWriter(outputFileName);
            out.write(outputContent);

        } catch (Exception e) {
            String eMsg = e.getMessage();
            if (eMsg != null) {
                // LOGGER.error(eMsg, e);
                // DialogManager.showErrorText("Cannnot write to file \n"
                // + outputFileName);
            } else {
                // LOGGER.error("Cannnot write to file \n" + outputFileName);
                // DialogManager.showErrorText("Cannnot write to file \n"
                // + outputFileName);
            }
            throw new Exception("Error writing file " + outputFileName, e);
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public static StringReader getTemplateStringReader(final String filePath) {

        InputStream stream = null;
        File f = new File(filePath);
        f.getAbsolutePath();
        stream = Generator.class.getResourceAsStream(filePath);

        StringBuilder out = new StringBuilder();
        byte[] b = new byte[4096];
        try {
            for (int n; (n = stream.read(b)) != -1;) {
                out.append(new String(b, 0, n));
            }
        } catch (IOException e) {
            String eMsg = e.getMessage();
            if (eMsg != null) {
                // LOGGER.error(eMsg, e);
                // DialogManager.showErrorText(eMsg);
            } else {
                // LOGGER.error("Error in VTAF: Error occured in templates");
                // DialogManager
                // .showErrorText("VTAF Error: Error occured in templates");
            }
            // LOGGER.info("Error occured in templates");
        } finally {
            try {
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return new StringReader(out.toString());
    }

}
