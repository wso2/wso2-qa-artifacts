package resources;

/**
 * NamedEntityBase provides convenience methods for entities that are named
 * where the generator often needs camel/pascal variations of the name.
 * Description field is optional to be used as descriptive comments for the
 * entity.
 * 
 * @author cmendis
 * 
 */
public abstract class NamedEntityBase {

    /** The name. */
    protected String name;

    /**
     * getter to find what it is.
     * 
     * @return what it is
     */
    public abstract String getEntity();

    /** The description. */
    protected String description;

    /** The modified state. */
    protected boolean modified;

    /** The index of the entity. */
    protected int index = -1;

    /**
     * Instantiates a new named entity base.
     * 
     * @param pname
     *            the name
     * @param pdescription
     *            the description
     */
    public NamedEntityBase(final String pname, final String pdescription) {
        this.name = pname;
        this.description = pdescription;
        this.modified = true;
    }

    /**
     * Checks if is modified.
     * 
     * @return true, if is modified
     */
    public abstract boolean isModified();

    /**
     * Sets the modified.
     * 
     * @param pmodified
     *            the new modified
     */
    public abstract void setModified(final boolean pmodified);

    /**
     * Instantiates a new named entity base.
     */
    public NamedEntityBase() {
        modified = true;
    }

    /**
     * Instantiates a new named entity base.
     * 
     * @param pname
     *            the name
     */
    public NamedEntityBase(final String pname) {
        this.name = pname;
        this.modified = true;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.modified = true;
        this.index = index;
    }

    /**
     * Gets the name.
     * 
     * @return the name
     */
    public abstract String getName();

    /**
     * Sets the name.
     * 
     * @param pname
     *            the new name
     */
    public abstract void setName(final String pname);

    /**
     * Gets the pascal name.
     * 
     * @return the pascal name
     */
    public abstract String getPascalName();

    /**
     * Gets the camel name.
     * 
     * @return the camel name
     */
    public abstract String getCamelName();

    /**
     * Gets the description.
     * 
     * @return the description
     */
    public abstract String getDescription();

    /**
     * Sets the description.
     * 
     * @param pdescription
     *            the new description
     */
    public abstract void setDescription(final String pdescription);

}
