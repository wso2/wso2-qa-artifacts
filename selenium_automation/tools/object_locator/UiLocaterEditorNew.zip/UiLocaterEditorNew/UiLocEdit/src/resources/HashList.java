package resources;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * A HashList can acts as a HashMap or a list for classes that extend from
 * NamedEntityBase.
 * 
 * @param <E>
 *            the element type
 * @author cmendis
 */
public class HashList < E > extends ArrayList<E> {

    /**
     * 
     */
    private static final long serialVersionUID = -1615692451150011048L;

    /** The names. */
    private List<String> names = new ArrayList<String>();

    /** The map. */
    private HashMap<String, E> map = new HashMap<String, E>();

    /**
     * {@inheritDoc}
     */
    @Override
    public final boolean add(final E value) {
        String name = ((NamedEntityBase) value).getName();
        int index = ((NamedEntityBase) value).getIndex();
        if (index == -1) {
            ((NamedEntityBase) value).setIndex(size());
        }

        names.add(name);
        map.put(name, value);
        return super.add(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void add(final int index, final E value) {
        String name = ((NamedEntityBase) value).getName();
        names.add(index, name);
        map.put(name, value);
        super.add(index, value);
        refreshList();
    }

    /**
     * Gets the names.
     * 
     * @return the names
     */
    public final List<String> getNames() {
        return names;
    }

    /**
     * Gets the element by name.
     * 
     * @param name
     *            the name
     * @return the element
     */
    public final E get(final String name) {
        return map.get(name);
    }

    /**
     * Gets the column index.
     * 
     * @param column
     *            the column
     * @return the column index
     */
    public final int getColumnIndex(final String column) {
        return names.indexOf(column);
    }

    /**
     * Gets the column name.
     * 
     * @param columnIndex
     *            the column index
     * @return the column name
     */
    public final String getColumnName(final int columnIndex) {
        return names.get(columnIndex);
    }

    /**
     * Gets the map.
     * 
     * @return the map
     */
    public final HashMap<String, E> getMap() {
        return map;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final boolean remove(final Object value) {
        String name = ((NamedEntityBase) value).getName();
        names.remove(name);
        map.remove(name);
        boolean result = super.remove(value);
        refreshList();
        return result;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void clear() {
        super.clear();
        map.clear();
        names.clear();
    }

    public void reloadHashList() {
        // TODO Auto-generated method stub
        List<E> entityList = new ArrayList<E>();
        for (String name : map.keySet()) {
            entityList.add(get(name));
        }
        Collections.sort(entityList, new Comparator<E>() {
            @Override
            public int compare(E o1, E o2) {
                // TODO Auto-generated method stub
                int Index1 = ((NamedEntityBase) o1).getIndex();
                int Index2 = ((NamedEntityBase) o2).getIndex();
                return (Index1 < Index2 ? -1 : (Index1 == Index2 ? 0 : 1));
            }
        });
        names.clear();
        super.clear();
        for (E e : entityList) {
            names.add(((NamedEntityBase) e).getName());
            super.add(e);
        }

    }

    public void sortHashList(List<String> names) {
        // TODO Auto-generated method stub
        this.names = names;
        for (int i = 0; i < names.size(); i++) {
            NamedEntityBase entity = (NamedEntityBase) get(names.get(i));
            // entity.setIndex(i);
            if (entity.getIndex() != i) {
                entity.setIndex(i);
            }
        }
    }

    private void refreshList() {
        // TODO Auto-generated method stub
        for (int i = 0; i < super.size(); i++) {
            NamedEntityBase entity = (NamedEntityBase) get(i);
            // entity.setIndex(i);
            if (entity.getIndex() != i) {
                entity.setIndex(i);
            }
        }

    }

}
