package domain;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import ui.uiDesiner;



/*
 * author msmuttettuwa
 */
public class displayInfo {

    private final uiDesiner uiDes = new uiDesiner();

    public void errMsg(final String err) {
        JOptionPane.showMessageDialog(null, err, "TC-Generator Error",
                JOptionPane.ERROR_MESSAGE,
                new ImageIcon(uiDesiner.geticonImg()));
    }

    public static void Error(String message) {
        JOptionPane.showMessageDialog(null, message,
                "TC-Generator - Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void Werning(String message) {
        JOptionPane.showMessageDialog(null, message,
                "TC-Generator - Warning", JOptionPane.WARNING_MESSAGE);
    }

    public static void Question(String message) {
        JOptionPane.showMessageDialog(null, message,
                "TC-Generator - Question", JOptionPane.QUESTION_MESSAGE);
    }
}
