package domain;

import resources.HashList;
import resources.Parameter;
/*
 * author msmuttettuwa
 */
public class savePage {

    private static String fileSavePath;
    // private static Map<String, String> tableValues;
    private static String pascalName;
    private static HashList<Parameter> tableValues;

    public void setObjects(String fullFilePath, HashList<Parameter> values,
            String fileName) {

        setFileSavePath(fullFilePath);
        setTableValues(values);
        setPascalName(fileName);

    }

    public static String getFileSavePath() {
        return fileSavePath;
    }

    public static void setFileSavePath(final String fileSavePath) {
        savePage.fileSavePath = fileSavePath;
    }

    public static HashList<Parameter> getTableValues() {
        return tableValues;
    }

    public static void setTableValues(final HashList<Parameter> tableValues) {
        savePage.tableValues = tableValues;
    }

    public static String getPascalName() {
        return pascalName;
    }

    public static void setPascalName(String pascalName) {
        savePage.pascalName = pascalName;
    }

    /**
     * @param args
     */

}
