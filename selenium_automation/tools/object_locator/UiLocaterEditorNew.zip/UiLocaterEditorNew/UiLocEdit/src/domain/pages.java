package domain;

import japa.parser.ParseException;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import org.stringtemplate.v4.compiler.STParser.element_return;

import domain.displayInfo;

import ui.*;
import fileReader.*;

/*
 * author msmuttettuwa
 */
public class pages {

    private static uiDesiner uiDes;
    private static runtimePages rPages = new runtimePages();
    private static SourceParser sP = new SourceParser();
    private static String oldNode = "";
    public static DefaultMutableTreeNode newNode = null;
    // private static ArrayList<String> objectNames;
    // private static ArrayList<String> objLocaters;
    public static JTree tree;
    private static boolean isTableModified = false;
    public static DefaultTableModel model;
    private static ArrayList<String> OldObjectNames;
    private static ArrayList<String> OldObjLocaters;
    public static int editedRow = 0;
    private static boolean isOldObjectNamesExists = false;
    private static boolean isOldObjLocatersExists = false;
    private static JTable table;
    private static String saveToPage;
    public static DefaultMutableTreeNode SelectedNode = null;
    public static String oldPath = null;

    private static ArrayList<String> modifiedTableObjNames =
            new ArrayList<String>();
    private static ArrayList<String> modifiedTableObjLocaters =
            new ArrayList<String>();

    @SuppressWarnings("unused")
    private static int preRowCount = 0;

    @SuppressWarnings("static-access")
    public static void showTreeView() {

        // tree.setBackground(Color.getColor("#F5F5F5"));
        uiDes = new uiDesiner();

        DefaultMutableTreeNode pages = new DefaultMutableTreeNode("* Pages");

        String[] pgList = rPages.getPageList();

        for (int i = 0; i < pgList.length; i++) {
            String[] pgName = pgList[i].split(".java");
            if (pgName != null && !"".equals(pgName)) {
                pages.add(new DefaultMutableTreeNode(pgName[0]));
            } else {
                displayInfo.Error(uiDesiner.getExportProjectPath()
                        + File.separator + uiDesiner.getRuntimeFilsPath()
                        + File.separator + "android" + File.separator
                        + "invalied***");
            }

        }

        DefaultMutableTreeNode root =
                new DefaultMutableTreeNode("com.virtusa.isq.vtaf.runtime");
        // root.set
        root.add(pages);

        tree = new JTree(root);

        final Font currentFont = tree.getFont();
        int treeFont = uiDes.getTreeFontSize();
        final Font bigFont =
                new Font(currentFont.getName(), currentFont.getStyle(),
                        treeFont);
        tree.setFont(bigFont);
        JScrollPane pane = (new JScrollPane(tree));
        uiDes.j1.add(pane);

        tree.addTreeSelectionListener(new TreeSelectionListener() {

            @Override
            public void valueChanged(final TreeSelectionEvent e) {
                DefaultMutableTreeNode node;
                node =
                        (DefaultMutableTreeNode) tree
                                .getLastSelectedPathComponent();
                SelectedNode = node;
                selectPageOnTree(node);
            }
        });
    }
    
    

    @SuppressWarnings("static-access")
    public static void selectPageOnTree(
            final DefaultMutableTreeNode selecNode) {

        DefaultMutableTreeNode node = selecNode;

        if (node != null) {
            
                if (!("com.virtusa.isq.vtaf.runtime".equals(node.toString()) || "* Pages"
                        .equals(node.toString()))) {

                    if (newNode != null) {
                        oldNode = newNode.toString();
                    }
                    newNode = node;
                    String currentPath = null;
                    String rdo = null;
                    if("seleniumwebdriver".equals(uiDesiner.getImportedTemplet())){
                        
                      currentPath = uiDesiner.getRuntimeFilsPath()+File.separator+node.toString()+".java";
                        
                    }else if ("seetestjava".equals(uiDesiner.getImportedTemplet())) {
                        
                        rdo = uiDes.getSelectedRdo();
                        
                        if ("android".equals(rdo)) {
                            currentPath =
                                    getPageUIObgects(node.toString(), "android")
                                            + ".java";
                        } else if ("bb".equals(rdo)) {
                            currentPath =
                                    getPageUIObgects(node.toString(), "bb") + ".java";
                        } else if ("ios".equals(rdo)) {
                            currentPath =
                                    getPageUIObgects(node.toString(), "ios") + ".java";
                        } else {
                            currentPath =
                                    getPageUIObgects(node.toString(), "wp") + ".java";
                        }
                        
                    }
                    
                   
                    if (oldPath == null) {
                        oldPath = currentPath;
                    }
                    ArrayList<String> currentNodeObjNames = new ArrayList<String>();
                    ArrayList<String> currentNodeObjLocaters =
                            new ArrayList<String>();
                    currentNodeObjNames = getParserObjectNames(currentPath);
                    currentNodeObjLocaters = getParserObjectLocater(currentPath);

                    checkzzz(rdo, node, currentNodeObjNames,
                            currentNodeObjLocaters, oldPath, currentPath);
            }
        
            }
        }

    private static ArrayList<String> getParserObjectNames(String path) {
        try {
            sP.parseSource(path);
            return sP.objectNames();
        } catch (ParseException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }

    }

    private static ArrayList<String> getParserObjectLocater(String path) {
        try {
            sP.parseSource(path);
            return sP.objLocaters();
        } catch (ParseException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }

    }

    private static void checkzzz(final String rdo,
            final DefaultMutableTreeNode node, ArrayList<String> objName,
            ArrayList<String> objLocater, String oldNodePath,
            String currentNodePath) {
        ArrayList<String> oldNodeObjNames = new ArrayList<String>();
        ArrayList<String> oldNodeObjLocaters = new ArrayList<String>();
        ArrayList<String> currentNodeObjNames = new ArrayList<String>(objName);
        ArrayList<String> currentNodeObjLocaters =
                new ArrayList<String>(objLocater);
        if (!"".equals(oldNode)) {

            oldNodeObjNames = getParserObjectNames(oldNodePath);
            oldNodeObjLocaters = getParserObjectLocater(oldNodePath);

            isTableModified =
                    isCheckTableModifications(oldNodeObjNames,
                            oldNodeObjLocaters);
        }

        if (isTableModified || "".equals(oldNode)) {

            showTable(currentNodeObjNames, currentNodeObjLocaters, rdo);
            oldPath = currentNodePath;
            System.out.println("- selected node Name : " + node.toString());

        } else {
            if (!isOldObjectNamesExists && !isOldObjLocatersExists) {
                saveToPage = oldNode.toString();
                int selectedOption =
                        JOptionPane
                                .showConfirmDialog(
                                        null,
                                        "Do you want to Save the project? row number "
                                                + (editedRow + 1)
                                                + " 'ObjecName' and 'locater' has exist modifications.",
                                        "Choose", JOptionPane.YES_NO_OPTION,
                                        JOptionPane.WARNING_MESSAGE,
                                        new ImageIcon(uiDes.geticonImg()));

                if (selectedOption == JOptionPane.YES_OPTION) {
                    try {
                        uiDes.save(modifiedTableObjNames,
                                modifiedTableObjLocaters, rdo);
                        isTableModified = true;
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                } else {
                	showTable(currentNodeObjNames, currentNodeObjLocaters, rdo);
                    oldPath = currentNodePath;
                    System.out.println("- selected node Name : " + node.toString());
                }
            } else if (!isOldObjectNamesExists && isOldObjLocatersExists) {
                saveToPage = oldNode.toString();
                int selectedOption =
                        JOptionPane
                                .showConfirmDialog(
                                        null,
                                        "Do you want to Save the project? row number "
                                                + (editedRow + 1)
                                                + " 'ObjecName' has exist modifications.",
                                        "Choose", JOptionPane.YES_NO_OPTION,
                                        JOptionPane.WARNING_MESSAGE,
                                        new ImageIcon(uiDes.geticonImg()));

                if (selectedOption == JOptionPane.YES_OPTION) {
                	showTable(currentNodeObjNames, currentNodeObjLocaters, rdo);
                    oldPath = currentNodePath;
                    System.out.println("- selected node Name : " + node.toString());
                    try {
                        uiDes.save(modifiedTableObjNames,
                                modifiedTableObjLocaters, rdo);
                        isTableModified = true;
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                } else {
                	showTable(currentNodeObjNames, currentNodeObjLocaters, rdo);
                    oldPath = currentNodePath;
                    System.out.println("- selected node Name : " + node.toString());
                }
                tree.setSelectionPath(new TreePath(node));
            } else if (isOldObjectNamesExists && !isOldObjLocatersExists) {
                saveToPage = oldNode.toString();
                int selectedOption =
                        JOptionPane
                                .showConfirmDialog(
                                        null,
                                        "Do you want to Save the project? row number "
                                                + (editedRow + 1)
                                                + " 'locater' has exist modifications.",
                                        "Choose", JOptionPane.YES_NO_OPTION,
                                        JOptionPane.WARNING_MESSAGE,
                                        new ImageIcon(uiDes.geticonImg()));

                if (selectedOption == JOptionPane.YES_OPTION) {
                    try {
                        uiDes.save(modifiedTableObjNames,
                                modifiedTableObjLocaters, rdo);
                        isTableModified = true;
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                } else {
                	showTable(currentNodeObjNames, currentNodeObjLocaters, rdo);
                    oldPath = currentNodePath;
                    System.out.println("- selected node Name : " + node.toString());
                }
            }
        }
        oldNodeObjNames.clear();
        oldNodeObjLocaters.clear();
        currentNodeObjNames.clear();
        currentNodeObjLocaters.clear();

    }

    public static boolean isCheckTableModifications(
            ArrayList<String> OldObjectNames, ArrayList<String> OldObjLocaters) {

        for (editedRow = 0; editedRow < model.getRowCount(); editedRow++) {
            boolean aaa = true;
            if (OldObjectNames.size() != model.getRowCount()) {
                isOldObjectNamesExists = false;
            } else {
                isOldObjectNamesExists =
                        OldObjectNames.contains(model.getValueAt(editedRow, 0)
                                .toString());
                isOldObjLocatersExists =
                        OldObjLocaters.contains(model.getValueAt(editedRow, 1)
                                .toString());
            }

            if ((!isOldObjectNamesExists || !isOldObjLocatersExists)) {
                modifiedTableObjNames.clear();
                modifiedTableObjLocaters.clear();
                for (int i = 0; i < model.getRowCount(); i++) {

                    modifiedTableObjNames
                            .add(model.getValueAt(i, 0).toString());
                    modifiedTableObjLocaters.add(model.getValueAt(i, 1)
                            .toString());
                }

                break;
            }
            // currentObjectNames.add(model.getValueAt(i, 0).toString());
            // currentObjLocaters.add(model.getValueAt(i, 1).toString());
        }
        // boolean isOldObjectNamesExists =
        // currentObjectNames.containsAll(OldObjectNames);
        // boolean isOldObjLocatersExists =
        // currentObjLocaters.containsAll(OldObjLocaters);

        if ((isOldObjectNamesExists && isOldObjLocatersExists)
                || model.getRowCount() == 0) {
            return true;
        } else {
            return false;
        }
    }

    @SuppressWarnings("static-access")
    public static String getPageUIObgects(final String SelectdNodeName,
            final String device) {

        String pageName = SelectdNodeName;
        String filePath = null;
        if ("android".equals(device)) {
            filePath =
                    uiDes.getRuntimeFilsPath() + File.separator + "android"
                            + File.separator + pageName;
        } else if ("bb".equals(device)) {
            filePath =
                    uiDes.getRuntimeFilsPath() + File.separator + "bb"
                            + File.separator + pageName;
        } else if ("ios".equals(device)) {
            filePath =
                    uiDes.getRuntimeFilsPath() + File.separator + "ios"
                            + File.separator + pageName;
        } else {
            filePath =
                    uiDes.getRuntimeFilsPath() + File.separator + "wp"
                            + File.separator + pageName;
        }

        return filePath;

    }

    @SuppressWarnings("static-access")
    public static void showTable(final ArrayList<String> objectNames,
            final ArrayList<String> ObjLocaters, final String aDevice) {
        // , ArrayList<?> BbObjLocaters,ArrayList<?> iosObjLocaters,ArrayList<?>
        // wpObjLocaters

        model = new DefaultTableModel();
        table = new JTable(model);
        table.setBackground(Color.decode("#F8F8FF"));
        // table.setBackground(Color.decode("#F0F8FF"));
        table.setRowHeight(1, 30);
        int tblFont = uiDes.getTableFontSize();
        table.setFont(new Font("calibri", Font.PLAIN, tblFont));
        // JScrollPane scrollPane;

        model.addColumn("Object Name");

        if ("android".equals(aDevice)) {
            model.addColumn("Android");
        } else if ("bb".equals(aDevice)) {
            model.addColumn("Black Berry");
        } else if ("ios".equals(aDevice)) {
            model.addColumn("iOS");
        } else {
            model.addColumn("Object Locator");
        }
        if (objectNames != null || ObjLocaters != null || ObjLocaters != null) {
            for (int i = 0; i < objectNames.size(); i++) {
                model.addRow(new Object[] {objectNames.get(i),
                        ObjLocaters.get(i)});
            }

        }

        oldNode = newNode.toString();
        OldObjectNames = objectNames;
        OldObjLocaters = ObjLocaters;
        table.revalidate();
        table.repaint();
        uiDes.j2.removeAll();
        uiDes.j2.revalidate();
        uiDes.j2.repaint();
        uiDes.j2.add(new JScrollPane(table), BorderLayout.CENTER);
        preRowCount = model.getRowCount();

    }
    
    public static boolean isCheckModification(){
        boolean x = false;
        String path = null;
        String node = null;
        if(newNode!=null){

            if("seleniumwebdriver".equals(uiDesiner.getImportedTemplet())){

                path = uiDesiner.getRuntimeFilsPath()+File.separator+newNode.toString()+".java";
                 
             }else if ("seetestjava".equals(uiDesiner.getImportedTemplet())) {
                path = uiDesiner.getRuntimeFilsPath()+File.separator+uiDesiner.getSelectedRdo()+File.separator+node+".java";
             }
           
            ArrayList<String> OldObjectNamez = new ArrayList<String>();
            ArrayList<String> OldObjLocaterz = new ArrayList<String>();
            OldObjectNamez = getParserObjectNames(path);
            OldObjLocaterz = getParserObjectLocater(path);
            if(!isCheckTableModifications(OldObjectNamez, OldObjLocaterz)){
                int selectedOption =
                        JOptionPane
                                .showConfirmDialog(
                                        null,
                                        "Do you want to Save the project? row number "
                                                + " data table has exist modifications.",
                                        "Choose", JOptionPane.YES_NO_OPTION,
                                        JOptionPane.WARNING_MESSAGE,
                                        new ImageIcon(uiDes.geticonImg()));

                if (selectedOption == JOptionPane.YES_OPTION) {
                   return true;
                } 
            } 
        }
        return x;
    }

    public static void repainTree() {
        DefaultMutableTreeNode node =
                (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
       // selectPageOnTree(node);
        // showTable(objectNames, objLocaters, uiDes.getSelectedRdo());
        selectPageOnTree(node);
    }

    public static String getNewNode() {
        return newNode.toString();
    }

    /* public static ArrayList<String> getObjectNames() {
         return objectNames;
     }

     public static ArrayList<String> getObjLocaters() {
         return objLocaters;
     }*/

    public static DefaultTableModel getmodel() {
        return model;
    }

    public JTable getTable() {
        return table;
    }

    public static String getSaveToPage() {
        return saveToPage;
    }

    public static void setSaveToPage(String pageName) {
        pages.saveToPage = pageName;
    }

    public static ArrayList<String> getOldObjectNames() {
        return OldObjectNames;
    }

    public static ArrayList<String> getOldObjLocaters() {
        return OldObjLocaters;
    }

    public static ArrayList<String> getModifiedTableObjNames() {
        return modifiedTableObjNames;
    }

    public static ArrayList<String> getModifiedTableObjLocaters() {
        return modifiedTableObjLocaters;
    }

    public static void setIsTableModified(boolean b) {

        isTableModified = b;
    }

}
