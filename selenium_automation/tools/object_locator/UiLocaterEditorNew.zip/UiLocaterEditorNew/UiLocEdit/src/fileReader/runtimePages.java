package fileReader;

import java.io.File;
import java.io.FilenameFilter;

import org.stringtemplate.v4.compiler.STParser.element_return;

import domain.displayInfo;

import ui.*;

/*
 * author msmuttettuwa
 */
public class runtimePages {

    private String[] pageList = new String[0];
   // private static NewIstancePanel newIns;
    private final NewIstancePanel newIns = new NewIstancePanel();
    private final uiDesiner uiDes = new uiDesiner();

    public String[] getPageList() {

        String pp = null ;//= uiDesiner.getRuntimeFilsPath() + File.separator + "android";
        if("seleniumwebdriver".equals(uiDesiner.getImportedTemplet())){
            pp = uiDesiner.getTempRuntimeFilsPath();// 
        }else if("seetestjava".equals(uiDesiner.getImportedTemplet())) {
            pp = uiDesiner.getRuntimeFilsPath()+ File.separator + "android";;
        }
        
        if (new File(pp).exists()) {
            File path = new File(pp);
            String files[] = path.list();
            
            String yourpath = path.getAbsolutePath();
            File directory = new File(yourpath);
            String[] myFiles;
            FilenameFilter filter = new FilenameFilter() {
            public boolean accept(File directory, String fileName) {
                return fileName.endsWith(".java");
            }
            };
            myFiles = directory.list(filter);
            
            
            pageList = myFiles;
            return pageList;
        }
        return pageList;
    }
    
    public String[] getNewPageList() {

        String pp = null ;//= uiDesiner.getRuntimeFilsPath() + File.separator + "android";
        if("seleniumwebdriver".equals(uiDes.getImportedTemplet())){
            pp = newIns.getExportProjectPath();// 
        }else if("seetestjava".equals(uiDes.getImportedTemplet())) {
            pp = newIns.getExportProjectPath()+ File.separator + "android";;
        }
        
        if (new File(pp).exists()) {
            File path = new File(pp);
            String files[] = path.list();
            pageList = files;
            return pageList;
        }
        return pageList;
    }
    
    public static void getExportProjectTemplet(String exportProjectPath,String runtimeFilsPath){
        System.out.println("");
        File currentPath = new File(runtimeFilsPath);
        if(currentPath.exists()){
            File parentPath = new File(exportProjectPath).getParentFile();
            String templet = parentPath.getName();
            if("seleniumwebdriver".equals(templet)){
                uiDesiner.setImportedTemplet(templet);
            }else if ("seetestjava".equals(templet)) {
                uiDesiner.setImportedTemplet(templet);
            }else {
                displayInfo.Error("Not campatible project for this App ");
            }
            System.out.println(templet);
        }
        
    }

}
