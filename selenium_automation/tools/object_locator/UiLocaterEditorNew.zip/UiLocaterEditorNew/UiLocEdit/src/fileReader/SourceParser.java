package fileReader;

import japa.parser.JavaParser;
import japa.parser.ParseException;
import japa.parser.ast.CompilationUnit;
import japa.parser.ast.body.EnumConstantDeclaration;
import japa.parser.ast.body.EnumDeclaration;
import japa.parser.ast.visitor.VoidVisitorAdapter;

import java.io.*;
import java.util.*;
/*
 * 
 */
public class SourceParser {
    EnumVisitor enumV;
    EnumConstantVisitor enumConV;
    ArrayList<String> testMethodNames;
    String packageName;
    String className;
    ArrayList<String> objLocaters = new ArrayList<String>();
    ArrayList<String> objNames = new ArrayList<String>();

    public SourceParser() {
        enumV = new EnumVisitor();
        enumConV = new EnumConstantVisitor();
    }

    public void parseSource(final String file) throws ParseException,
            IOException {
        objNames.clear();
        objLocaters.clear();
        testMethodNames = new ArrayList<String>();
        FileInputStream in = new FileInputStream(file);

        CompilationUnit cu;
        try {
            cu = JavaParser.parse(in);
        } finally {
            in.close();
        }

        packageName = cu.getPackage().getName().toString();

        enumV = new EnumVisitor();
        enumConV = new EnumConstantVisitor();

        enumV.visit(cu, null);
        enumConV.visit(cu, null);
    }

    private class EnumVisitor extends VoidVisitorAdapter<Object> {

        @Override
        public void visit(final EnumDeclaration n, final Object arg) {

            n.getName();

        }
    }

    private class EnumConstantVisitor extends VoidVisitorAdapter<Object> {

        @Override
        public void visit(final EnumConstantDeclaration n, final Object arg) {

            objNames.add(n.getName());
            String locator = n.getArgs().get(0).toString();
            locator = locator.substring(1, locator.length() - 1);

            objLocaters.add(locator);

        }
    }

    public ArrayList<String> objectNames() {
        return objNames;
    }

    public ArrayList<String> objLocaters() {
        return objLocaters;
    }

}
