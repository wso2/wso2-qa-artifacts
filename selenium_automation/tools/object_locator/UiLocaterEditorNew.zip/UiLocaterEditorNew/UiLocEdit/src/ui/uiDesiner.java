package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSplitPane;
import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.io.FileUtils;

import domain.*;
import fileReader.*;
import resources.*;

/**
 * author msmuttettuwa
 **/
public class uiDesiner {

    private static String exportProjectPath;// =
                                            // "C:\\Users\\msmuttettuwa\\Desktop\\Deverlopment_core\\SEETEST_DEMO1\\SEETEST_DEMO1";
    // private static String exportProjectPath;
    private static String iconImg = (System.getProperty("user.dir")
            + File.separator + "src" + File.separator + "resources"
            + File.separator + "uiLocater.png");
    private static String PropFile = (System.getProperty("user.dir")
            + File.separator + "src" + File.separator + "vtafLocater.property");
    public static JPanel j1, j2;
    private static pages pg = new pages();
    public static JFrame frame;
    private static String SelectedRdo = "android";
    private static String newUIname;

    private static int TableFontSize = 14;
    private static int TreeFontSize = 12;
    private static boolean isImpotProj = false;
    private static boolean isUInameValied = true;
    private static SourceParser sP = new SourceParser();
    private static String input;
    private static savePage page;
    private static Generator gen;
    private static String importedTemplet;
    
	private static NewEnviement newEnv;
	private static SelectEnvironment selEnv;
	private static uiDesiner mainIns;

	static boolean isclosed = false;
    public uiDesiner() {

    }
    
    public static void startUpInit() {
        if(frame!=null){
            frame.dispose();
        }
        frame = new JFrame("VTAF UI-Object Editer");
        frame.setIconImage(new ImageIcon(geticonImg()).getImage());
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        // Add the menubar to the frame
        frame.setJMenuBar(menuBar);

        JMenu fileMenu = new JMenu("  File  ");
        JMenu helpMenu = new JMenu("  Help  ");
        menuBar.add(fileMenu);
        menuBar.add(helpMenu);
        JMenuItem importProjAction = new JMenuItem(" Import Project  ");
        JMenuItem exitAction = new JMenuItem(" Exit  ");
        JMenuItem aboutAction = new JMenuItem(" About  ");

        fileMenu.add(importProjAction);
        fileMenu.add(exitAction);
        helpMenu.add(aboutAction);

        j1 = new JPanel(new GridLayout(1, 1));
        j2 = new JPanel(new GridLayout(1, 1));
        JPanel j3 = new JPanel(new GridLayout(1, 1));

        final JSplitPane splitPane =
                new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setBackground(Color.getColor("#C0C0C0"));
        splitPane.setDividerSize(10);

        splitPane.setTopComponent(j1);
        splitPane.setBottomComponent(j2);

        frame.getContentPane().add(splitPane, BorderLayout.CENTER);
        frame.setSize(150, 150);
        frame.setVisible(true);
        splitPane.setDividerLocation(220);
        // make the frame half the height and width
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int height = screenSize.height;
        int width = screenSize.width;
        frame.setSize((width / 3) * 2, (height / 3) * 2);
        // center the jframe on screen
        frame.setLocationRelativeTo(null);
        
     //   splitPane.setDividerLocation(220);
        splitPane.setOneTouchExpandable(true);
        frame.setVisible(true);
        splitPane.setDividerLocation(220);
        exitAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {

                exitFromApp();

            }
        });
        
        importProjAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                importProject();
            }
        });
        
        aboutAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {

                JOptionPane.showMessageDialog(null,
                        "Copyright (C) Virtusa corp.All rights reserved",
                        "VTAF UI Locater Editer", JOptionPane.ERROR_MESSAGE,
                        new ImageIcon(geticonImg()));
            }
        });
    }
    
    public static void seleniumWdUI() {
        if(frame!=null){
            frame.dispose();
        }
        frame = new JFrame("VTAF UI-Object Editer");
        frame.setIconImage(new ImageIcon(geticonImg()).getImage());
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        // Add the menubar to the frame
        frame.setJMenuBar(menuBar);

        JMenu fileMenu = new JMenu("  File  ");
        //JMenu currTemplet = new JMenu("  Current Templet  ");
        JMenu editMenu = new JMenu("  Edit  ");
        JMenu environmentMenu = new JMenu("  Environment  ");
        JMenu helpMenu = new JMenu("  Help  ");
        menuBar.add(fileMenu);
        //menuBar.add(currTemplet);
        menuBar.add(editMenu);
        menuBar.add(environmentMenu);
        menuBar.add(helpMenu);
        // Create and add simple menu item to one of the drop down menu
        JMenuItem importProjAction = new JMenuItem(" Import Project  ");
        JMenuItem saveAction = new JMenuItem(" Save  ");
        //JMenuItem saveAsAction = new JMenuItem(" Save As ");
        JMenuItem exitAction = new JMenuItem(" Exit  ");
        // JMenuItem editProFileAction = new JMenuItem(" Edit PropertyFile  ");
        JMenuItem addNewobject = new JMenuItem(" Add new UI object  ");
        JMenuItem removeObject = new JMenuItem(" Remove selected UI object  ");
         JMenuItem seleniumWD = new JMenuItem(" Selenium WebDriver  ");
         
        JMenuItem newEnvironment = new JMenuItem(" New Environment  ");
 		JMenuItem selectEnvironment = new JMenuItem(" Select Environment  ");
        // JMenuItem editTableFontSize = new
        // JMenuItem(" Edit Table Font Size  ");
        JMenuItem aboutAction = new JMenuItem(" About  ");

        
        
        // Create a ButtonGroup and add both radio Button to it. Only one radio
        // button in a ButtonGroup can be selected at a time.

        fileMenu.add(importProjAction);
        fileMenu.add(saveAction);
      //  fileMenu.add(saveAsAction);
        fileMenu.add(exitAction);
       // currTemplet.add(seleniumWD);
        editMenu.add(addNewobject);
        editMenu.add(removeObject);
        
        environmentMenu.add(newEnvironment);
		environmentMenu.add(selectEnvironment);
        /* editMenu.add(editTreeFontSize);
         editMenu.add(editTableFontSize);*/
        helpMenu.add(aboutAction);

        j1 = new JPanel(new GridLayout(1, 1));
        j2 = new JPanel(new GridLayout(1, 1));
        JPanel j3 = new JPanel(new GridLayout(1, 1));

        final JSplitPane splitPane =
                new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setBackground(Color.getColor("#C0C0C0"));
        splitPane.setDividerSize(10);

        splitPane.setTopComponent(j1);
        splitPane.setBottomComponent(j2);

        frame.getContentPane().add(splitPane, BorderLayout.CENTER);
        frame.setSize(150, 150);
        frame.setVisible(true);

        // make the frame half the height and width
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int height = screenSize.height;
        int width = screenSize.width;
        frame.setSize((width / 3) * 2, (height / 3) * 2);
        // center the jframe on screen
        frame.setLocationRelativeTo(null);
        // frame.pack();
      /*  if (exportProjectPath != null) {
            pg.showTreeView();
        }*/

      //  splitPane.setDividerLocation(220);
        splitPane.setOneTouchExpandable(true);
        frame.setVisible(true); 
        splitPane.setDividerLocation(220);
        importProjAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                importProject();
            }
        });

        saveAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {

                // save(modifiedTableObjNames,modifiedTableObjLocaters,rdo);
                DirectSave();

            }

        });

        addNewobject.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                if (isImpotProj) {
                    if (isNewUIobjectValied() && input != null) {
                        pg.getmodel().addRow(new Object[] {newUIname, ""});
                    }
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                    geticonImg()));
                }
            }
        });
        
        removeObject.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                if (isImpotProj) {
                    removeSelectedRow();
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                    geticonImg()));
                }
            }
        });

        aboutAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {

                JOptionPane.showMessageDialog(null,
                        "Copyright (C) Virtusa corp.All rights reserved",
                        "VTAF UI Locater Editer", JOptionPane.ERROR_MESSAGE,
                        new ImageIcon(geticonImg()));
            }
        });

        exitAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {

                exitFromApp();

            }
        });
        
        newEnvironment.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(final ActionEvent e) {
				if (exportProjectPath != null) {
					newEnv = new NewEnviement(mainIns);
					newEnv = new NewEnviement(getTempRuntimeFilsPath());
					
					if (isclosed) {
						pg.repainTree();
						closeProject();	
					}
					
				} else {
					JOptionPane.showMessageDialog(null,
							"Please import a project", "UI-Locater Error",
							JOptionPane.ERROR_MESSAGE, new ImageIcon(
									geticonImg()));
					//androidAction.setSelected(true);
				}

			}
		});
		
		selectEnvironment.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(final ActionEvent e) {
				if (exportProjectPath != null) {
					selEnv = new SelectEnvironment(mainIns);
					selEnv = new SelectEnvironment(getTempRuntimeFilsPath());
					
					if (isclosed) {
						j1.removeAll();
						j2.removeAll();
						j1.repaint();
						j2.repaint();
						pg.showTreeView();
	                    frame.revalidate();
	                    frame.repaint();
						pg.repainTree();
						closeProject();	
					}
			
				} else {
					JOptionPane.showMessageDialog(null,
							"Please import a project", "UI-Locater Error",
							JOptionPane.ERROR_MESSAGE, new ImageIcon(
									geticonImg()));
					//androidAction.setSelected(true);
				}

			}
		});
		
	

        
        
    }
    
    @SuppressWarnings("static-access")
    public static void seeTestUI() {
        if(frame!=null){
            frame.dispose();
        }
        frame = new JFrame("VTAF UI-Object Editer");
        frame.setIconImage(new ImageIcon(geticonImg()).getImage());
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        // Add the menubar to the frame
        frame.setJMenuBar(menuBar);

        JMenu fileMenu = new JMenu("  File  ");
        JMenu deviceMenu = new JMenu("  * Select Device  ");
        JMenu editMenu = new JMenu("  Edit  ");
        JMenu helpMenu = new JMenu("  Help  ");
        menuBar.add(fileMenu);
        menuBar.add(deviceMenu);
        menuBar.add(editMenu);
        menuBar.add(helpMenu);
        // Create and add simple menu item to one of the drop down menu
        JMenuItem importProjAction = new JMenuItem(" Import Project  ");
        JMenuItem saveAction = new JMenuItem(" Save  ");
        JMenuItem saveAsAction = new JMenuItem(" Save As ");
        JMenuItem exitAction = new JMenuItem(" Exit  ");
        // JMenuItem editProFileAction = new JMenuItem(" Edit PropertyFile  ");
        JMenuItem addNewobject = new JMenuItem(" Add new UI object  ");
        JMenuItem removeObject = new JMenuItem(" Remove selected UI object  ");
        // JMenuItem editTreeFontSize = new JMenuItem(" Edit Tree Font Size  ");
        // JMenuItem editTableFontSize = new
        // JMenuItem(" Edit Table Font Size  ");
        JMenuItem aboutAction = new JMenuItem(" About  ");

        ButtonGroup group = new ButtonGroup();
        final JRadioButtonMenuItem androidAction =
                new JRadioButtonMenuItem("android");
        JRadioButtonMenuItem bbAction = new JRadioButtonMenuItem("blackberry");
        JRadioButtonMenuItem iosAction = new JRadioButtonMenuItem("iOS");
        JRadioButtonMenuItem wpAction =
                new JRadioButtonMenuItem("windows Phone");
        
        // Create a ButtonGroup and add both radio Button to it. Only one radio
        // button in a ButtonGroup can be selected at a time.

        fileMenu.add(importProjAction);
        fileMenu.add(saveAction);
        fileMenu.add(saveAsAction);
        fileMenu.add(exitAction);

        group.add(androidAction);
        group.add(bbAction);
        group.add(iosAction);
        group.add(wpAction);
        deviceMenu.add(androidAction);
        deviceMenu.add(bbAction);
        deviceMenu.add(iosAction);
        deviceMenu.add(wpAction);
        editMenu.add(addNewobject);
        editMenu.add(removeObject);
        /* editMenu.add(editTreeFontSize);
         editMenu.add(editTableFontSize);*/
        helpMenu.add(aboutAction);
        androidAction.setSelected(true);

        j1 = new JPanel(new GridLayout(1, 1));
        j2 = new JPanel(new GridLayout(1, 1));
        JPanel j3 = new JPanel(new GridLayout(1, 1));

        final JSplitPane splitPane =
                new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setBackground(Color.getColor("#C0C0C0"));
        splitPane.setDividerSize(10);

        splitPane.setTopComponent(j1);
        splitPane.setBottomComponent(j2);

        frame.getContentPane().add(splitPane, BorderLayout.CENTER);
        frame.setSize(150, 150);
        frame.setVisible(true);

        // make the frame half the height and width
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int height = screenSize.height;
        int width = screenSize.width;
        frame.setSize((width / 3) * 2, (height / 3) * 2);
        // center the jframe on screen
        frame.setLocationRelativeTo(null);
        // frame.pack();
       /* if (exportProjectPath != null) {
            pg.showTreeView();
        }*/

     //   splitPane.setDividerLocation(220);
        splitPane.setOneTouchExpandable(true);
        frame.setVisible(true);
        splitPane.setDividerLocation(220);

        androidAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                if (exportProjectPath != null) {
                    SelectedRdo = "android";
                    pg.repainTree();
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                    geticonImg()));
                    androidAction.setSelected(true);
                }

            }
        });

        bbAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                if (exportProjectPath != null) {
                    SelectedRdo = "bb";
                    pg.repainTree();
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                    geticonImg()));
                    androidAction.setSelected(true);
                }

            }
        });

        iosAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {

                if (exportProjectPath != null) {
                    SelectedRdo = "ios";
                    pg.repainTree();
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                    geticonImg()));
                    androidAction.setSelected(true);
                }

            }
        });

        wpAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                if (exportProjectPath != null) {
                    SelectedRdo = "wp";
                    frame.revalidate();
                    pg.repainTree();
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                    geticonImg()));
                    androidAction.setSelected(true);
                }

            }
        });

        importProjAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                importProject();
            }
        });

        saveAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {

                // save(modifiedTableObjNames,modifiedTableObjLocaters,rdo);
                DirectSave();

            }

        });

        addNewobject.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                if (isImpotProj) {
                    if (isNewUIobjectValied() && input != null) {
                        pg.getmodel().addRow(new Object[] {newUIname, ""});
                    }
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                    geticonImg()));
                    androidAction.setSelected(true);
                }

                // isNewUIobjectValied();
            }
        });

        /*  editTreeFontSize.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                if(exportProjectPath!=null){
                editTreeFontSize();
              //  pages.tree.revalidate();
                pages.tree.repaint();
                }else {
                    JOptionPane.showMessageDialog(null, "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(geticonImg()));
                }
            }
        });*/

        removeObject.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {
                if (isImpotProj) {
                    removeSelectedRow();
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Please import a project", "UI-Locater Error",
                            JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                    geticonImg()));
                    androidAction.setSelected(true);
                }
            }
        });

        /* editTableFontSize.addActionListener(new ActionListener() {
             
             @Override
             public void actionPerformed(ActionEvent e) {
                 if(exportProjectPath!=null){
                 editTableFontSize();
                 }else {
                     JOptionPane.showMessageDialog(null, "Please import a project", "UI-Locater Error",
                             JOptionPane.ERROR_MESSAGE, new ImageIcon(geticonImg()));
               }
             }
         });*/

        aboutAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(final ActionEvent e) {

                JOptionPane.showMessageDialog(null,
                        "Copyright (C) Virtusa corp.All rights reserved",
                        "VTAF UI Locater Editer", JOptionPane.ERROR_MESSAGE,
                        new ImageIcon(geticonImg()));
            }
        });

        exitAction.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {

                exitFromApp();

            }
        });
    }

    protected static void exitFromApp() {

        int response =
                JOptionPane.showConfirmDialog(null,
                        "Do you want to Close UI-Editer ?", "Confirm",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, new ImageIcon(
                                geticonImg()));
        if (response == JOptionPane.NO_OPTION) {
            // //////////////
        } else if (response == JOptionPane.YES_OPTION) {
            System.exit(0);
        } else if (response == JOptionPane.CLOSED_OPTION) {
            // /////////////////
        }

    }

    protected static void DirectSave() {
        ArrayList<String> currentTableObjNames = new ArrayList<>();
        ArrayList<String> currentTableObjLocaters = new ArrayList<>();
        boolean saveBreak =false;
        if("seleniumwebdriver".equals(uiDesiner.getImportedTemplet())){
            for (int i = 0; i < pages.model.getRowCount(); i++) {
            	if (currentTableObjNames.contains(pages.model.getValueAt(i, 0).toString())) {
            		 JOptionPane.showMessageDialog(null, "Duplicate UI-Locater Name ["+pages.model.getValueAt(i, 0).toString()+"] !",
                             "UI-Locater Error", JOptionPane.ERROR_MESSAGE,
                             new ImageIcon(geticonImg()));
            		 saveBreak = true;
            		 //break;
                } else {
                currentTableObjNames.add(pages.model.getValueAt(i, 0).toString());
                currentTableObjLocaters
                        .add(pages.model.getValueAt(i, 1).toString());
                }
            }
            try {
            	if (!saveBreak) {
            		save(currentTableObjNames, currentTableObjLocaters, null,
                            pages.newNode.toString());
            	}
                
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }else if("seetestjava".equals(uiDesiner.getImportedTemplet())){

            
            String rdo = getSelectedRdo();
            for (int i = 0; i < pages.model.getRowCount(); i++) {

                currentTableObjNames.add(pages.model.getValueAt(i, 0).toString());
                currentTableObjLocaters
                        .add(pages.model.getValueAt(i, 1).toString());
            }
            try {
                save(currentTableObjNames, currentTableObjLocaters, rdo,
                        pages.newNode.toString());
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }

    protected static void removeSelectedRow() {
        if (pg.getTable().getSelectedRow() == -1) {

            JOptionPane.showMessageDialog(null, "Please select a row !",
                    "UI-Locater Error", JOptionPane.ERROR_MESSAGE,
                    new ImageIcon(geticonImg()));

        } else {
            int selectedrow = pg.getTable().getSelectedRow();
            pg.getmodel().removeRow(selectedrow);
        }
    }

    protected static boolean isNewUIobjectValied() {
        try {
            newUIname = null;
            isUInameValied = true;

            Pattern p =
                    Pattern.compile("[^a-zA-Z0-9_]+", Pattern.CASE_INSENSITIVE);
            do {
                DefaultMutableTreeNode node;
                node =
                        (DefaultMutableTreeNode) pages.tree
                                .getLastSelectedPathComponent();
                if (node != null) {

                    if (!"com.virtusa.isq.vtaf.runtime".equals(node.toString())
                            || !"* Pages".equals(node.toString())) {
                        String ss = node.toString();
                        input =
                                JOptionPane.showInputDialog(null,
                                        "Enter the New UI object Name",
                                        "Add UI - " + ss,
                                        JOptionPane.QUESTION_MESSAGE);
                        if (input != null) {

                            for (int i = 0; i < pg.getmodel().getRowCount(); i++) {

                                String uiName =
                                        (pg.getmodel().getValueAt(i, 0)
                                                .toString());
                                Matcher m = p.matcher(input);
                                boolean b = m.find();
                                if (uiName.equalsIgnoreCase(input) || b) {
                                    isUInameValied = false;
                                    JOptionPane
                                            .showMessageDialog(
                                                    null,
                                                    "Duplicate UI-Locater Name ["+input+"]",
                                                    "UI-Locater Error",
                                                    JOptionPane.ERROR_MESSAGE,
                                                    new ImageIcon(geticonImg()));
                                    break;
                                } else {
                                	isUInameValied = true;
                                }
                            }
                            newUIname = input;
                            System.out.println(input);

                        } else {
                            isUInameValied = true;

                        }

                    } else {
                        JOptionPane
                                .showMessageDialog(
                                        null,
                                        "Can't add UI object into root. Please Select a page from pages hierarchy !",
                                        "UI-Locater Error",
                                        JOptionPane.ERROR_MESSAGE,
                                        new ImageIcon(geticonImg()));
                    }

                } else {
                    JOptionPane
                            .showMessageDialog(
                                    null,
                                    "Can't add UI object. Please Select a page from pages hierarchy !",
                                    "UI-Locater Error",
                                    JOptionPane.ERROR_MESSAGE, new ImageIcon(
                                            geticonImg()));
                }

            } while (!isUInameValied);

        } catch (java.lang.NullPointerException n) {

        } catch (Exception a) {
            // TODO: handle exception
        }
        return isUInameValied;
    }

    protected static void editTreeFontSize() {
        String[] choicesTree = {"08", "09", "10", "11", "12", "13", "14"};
        String input =
                (String) JOptionPane.showInputDialog(null,
                        "Choose Font size..", "TreeView Font Size",
                        JOptionPane.QUESTION_MESSAGE, new ImageIcon(
                                geticonImg()), // Use
                        // default
                        // icon
                        choicesTree, // Array of choices
                        choicesTree[3]); // Initial choice
        if (input != null) {
            TreeFontSize = Integer.parseInt(input);
        }

    }

    protected static void editTableFontSize() {
        String[] choicesTable = {"10", "11", "12", "13", "14", "15", "16"};
        String input =
                (String) JOptionPane.showInputDialog(null,
                        "Choose Font size..", "TableView Font Size",
                        JOptionPane.QUESTION_MESSAGE, new ImageIcon(
                                geticonImg()), // Use
                        // default
                        // icon
                        choicesTable, // Array of choices
                        choicesTable[4]); // Initial choice
        if (input != null) {
            TableFontSize = Integer.parseInt(input);
        }

    }

    @SuppressWarnings("static-access")
    protected static void importProject() {
        if (!isImpotProj) {

            JFileChooser chooser =
                    new JFileChooser(System.getProperty("user.home"));
            chooser.setCurrentDirectory(new java.io.File("."));
            chooser.setDialogTitle("Choose Generated Project");
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            chooser.setAcceptAllFileFilterUsed(false);

            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                // System.out.println("getCurrentDirectory(): " +
                // chooser.getCurrentDirectory());
                System.out.println("getSelectedFile() : "
                        + chooser.getSelectedFile());
                exportProjectPath = chooser.getSelectedFile().toString();
                ///////////////////////////
                
                
                copyFile(new File(getRuntimeFilsPath()), new File(getTempRuntimeFilsPath()));
                runtimePages.getExportProjectTemplet(exportProjectPath,getTempRuntimeFilsPath());
                //////////////////////////
              //  runtimePages.getExportProjectTemplet(exportProjectPath,getRuntimeFilsPath());
                lordUI();
                
               // if (new File(actualPath).exists()) {
                
                    pg.showTreeView();
                    frame.revalidate();
                    frame.repaint();
                    isImpotProj = true;
            //    } else {
                  /*  JOptionPane.showMessageDialog(null,
                            "Imported Project is not valied..!",
                            "UI-Locater Error", JOptionPane.ERROR_MESSAGE,
                            new ImageIcon(geticonImg()));*/
            //    }

            } else {
                System.out.println("No Selection ");
            }

        } else {
            int selectedOption =
                    JOptionPane.showConfirmDialog(null,
                            "Do you want to close the project?", "Choose",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE, new ImageIcon(
                                    geticonImg()));

            if (selectedOption == JOptionPane.YES_OPTION) {
            	isImpotProj = false;
            	//pg.repainTree();
				closeImportedProject();
            }
        }
    }

    private static void lordUI() {
       
        if("seleniumwebdriver".equals(getImportedTemplet())){

           seleniumWdUI();
            
        }else if ("seetestjava".equals(importedTemplet)) {
            String actualPath =
                    getRuntimeFilsPath() + File.separator + "android";
            seeTestUI();
            
        }
    }
	private static void closeImportedProject() {
j1.removeAll();
j2.removeAll();
j1.repaint();
j2.repaint();
importProject();

	}
	static void closeProject() {
j1.removeAll();
j2.removeAll();
j1.repaint();
j2.repaint();
//open(new File(getTempRuntimeFilsPath()));
//importProject();

	}
 /*   private static void closeImportedProject() {
        if(pages.isCheckModification()){
            DirectSave();
        }
        startUpInit();
        isImpotProj = false;
    }*/

    public static void save(ArrayList<String> editedNodeObjNames,
            ArrayList<String> editedNodeObjLocaters, String rdo)
            throws Exception {
        
        String fileName = pages.getSaveToPage();

        String folderPath = getTempRuntimeFilsPath();
        
        String fullFilePath = null;
        
        if("seleniumwebdriver".equals(uiDesiner.getImportedTemplet())){
            fullFilePath = folderPath;
        }else if("seetestjava".equals(uiDesiner.getImportedTemplet())) {
            folderPath = folderPath.concat(File.separator + rdo);
            fullFilePath = folderPath + File.separator;
        }

        ArrayList<String> objectNames = new ArrayList<>(editedNodeObjNames);
        ArrayList<String> objectLocators =
                new ArrayList<>(editedNodeObjLocaters);

        HashList<Parameter> val = new HashList<Parameter>();

        Map<String, String> values = new HashMap<String, String>();

        for (int i = 0; i < objectNames.size(); i++) {
            values.put(objectNames.get(i), objectLocators.get(i));

            Parameter param = new Parameter(objectNames.get(i));
            param.setValue(objectLocators.get(i));
            val.add(param);
        }

        page = new savePage();
        page.setObjects(fullFilePath, val, fileName);
        Generator.createContent("page", page,
                Generator.getTemplateStringReader("stringTemp.stg"),
                fullFilePath);
        copyFile(new File(getTempRuntimeFilsPath()),new File(getRuntimeFilsPath()));
        pages.repainTree();
        objectNames.clear();
        objectLocators.clear();
        pages.repainTree();
    }

    public static void save(ArrayList<String> editedNodeObjNames,
            ArrayList<String> editedNodeObjLocaters, String rdo, String fileName)
            throws Exception {

        String folderPath = getTempRuntimeFilsPath();
        
        String fullFilePath = null;// + File.separator +
                                                          // fileName;
        // /// String fullFilePath = "newPages";
        if("seleniumwebdriver".equals(uiDesiner.getImportedTemplet())){
            fullFilePath = folderPath;
        }else if("seetestjava".equals(uiDesiner.getImportedTemplet())) {
            folderPath = folderPath.concat(File.separator + rdo);
            fullFilePath = folderPath + File.separator;
        }

        ArrayList<String> objectNames = new ArrayList<>(editedNodeObjNames);
        ArrayList<String> objectLocators =
                new ArrayList<>(editedNodeObjLocaters);

        HashList<Parameter> val = new HashList<Parameter>();

        Map<String, String> values = new HashMap<String, String>();

        for (int i = 0; i < objectNames.size(); i++) {
            values.put(objectNames.get(i), objectLocators.get(i));

            Parameter param = new Parameter(objectNames.get(i));
            param.setValue(objectLocators.get(i));
            val.add(param);
        }

        page = new savePage();
        page.setObjects(fullFilePath, val, fileName);
        Generator.createContent("page", page,
                Generator.getTemplateStringReader("stringTemp.stg"),
                fullFilePath);
        copyFile(new File(getTempRuntimeFilsPath()),new File(getRuntimeFilsPath()));
        pages.repainTree();
        objectNames.clear();
        objectLocators.clear();
        pages.repainTree();
    }

    public static String geticonImg() {
        return iconImg;
    }

    public String getPropFile() {
        return PropFile;
    }

    public static String getRuntimeFilsPath() {
        return exportProjectPath + File.separator + "src" + File.separator
                + "main" + File.separator + "java" + File.separator + "com"
                + File.separator + "virtusa" + File.separator + "isq"
                + File.separator + "vtaf" + File.separator + "runtime"
                + File.separator + "pages";

    }
    public static String getTempRuntimeFilsPath() {
        return exportProjectPath + File.separator + "src" + File.separator
                + "main" + File.separator + "resources" + File.separator +"pages";

    }
    public static String getSelectedRdo() {
        return SelectedRdo;
    }

    public static int getTableFontSize() {
        return TableFontSize;
    }

    public static int getTreeFontSize() {
        return TreeFontSize;
    }

    public static String getExportProjectPath() {
        // TODO Auto-generated method stub
        return exportProjectPath;
    }

    public static String getImportedTemplet() {
        return importedTemplet;
    }
    
    public static void setImportedTemplet(String templet) {
        uiDesiner.importedTemplet = templet;
        
    }

    public static void copyFile(File srcDir, File destDir){
		File[] fileList = srcDir.listFiles();
		try {
		 for (File srcFile: srcDir.listFiles()) {
			 srcFile.getAbsolutePath();
		        if (!srcFile.isDirectory()) {
		            try {
						FileUtils.copyFileToDirectory(srcFile, destDir);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
		    }
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog (null, "Import Selenium Webdriver project ", "VTAF - Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}


	}
    
    public static void open(File file){
   String ProjectPath = file.getAbsolutePath().toString();
    runtimePages.getExportProjectTemplet(exportProjectPath,getRuntimeFilsPath());
	seleniumWdUI();
	pg.showTreeView();
    frame.revalidate();
    frame.repaint();
    isImpotProj = true;
    }
    
}
