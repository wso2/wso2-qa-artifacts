package ui;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
//import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.commons.io.FileUtils;

import domain.pages;

public class NewEnviement {

	private static uiDesiner excistingMainInstance;
	private static NewIstancePanel excistingNewInstance;
	 private static pages pg = new pages();
	public NewEnviement(String parentPath) {

		JLabel lab1 = new JLabel("Environment :", JLabel.LEFT);
		JTextField envEnter = new JTextField("Enter Environment here", 20);
		envEnter.setVisible(true);

		JPanel myPanel = new JPanel();

		myPanel.add(lab1);
		myPanel.add(envEnter);

		int result = JOptionPane.showConfirmDialog(null, myPanel,
				"Select the prefered template", JOptionPane.OK_OPTION);
		if (result == JOptionPane.OK_OPTION) {
		    uiDesiner.isclosed = true;

			String foldername = envEnter.getText().toString();

			File parentDir = new File(parentPath);
			File defaultDir = new File(parentPath + File.separator + "default");
			File theDir = new File(parentPath + File.separator + foldername);
			if (!defaultDir.exists()) {
				System.out.println("creating directory: " + "default");
				boolean result2 = false;

				try {
					defaultDir.mkdir();
					result2 = true;
				} catch (SecurityException se) {
					// handle it
				}
				if (result2) {
					System.out.println("DIR created");
					File fi = null;
					File file = new File(parentPath + File.separator
							+ "default");

					fi = new File(file.getAbsolutePath());
					try {
						copyFile(parentDir, file);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					/*
					 * System.out.println(fi.getAbsolutePath() + " " +
					 * tables.size()); XmlCreate.save(fi, tables, attrib);
					 */

				}

			}
			if (!theDir.exists()) {
				System.out.println("creating directory: " + foldername);
				boolean result1 = false;

				try {
					theDir.mkdir();
					result1 = true;
				} catch (SecurityException se) {
					// handle it
				}
				if (result1) {
					System.out.println("DIR created");
					File fi = null;
					File file = new File(parentPath + File.separator
							+ foldername);
					try {
						copyFile(parentDir, file);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//fi = new File(file.getAbsolutePath());
					/*
					 * System.out.println(fi.getAbsolutePath() + " " +
					 * tables.size()); XmlCreate.save(fi, tables, attrib);
					 */

					// getExistingMainInstance().setVisible(false);

					NewIstancePanel nw = NewIstancePanel.getMainIns();
					nw.startUpInit();
					//nw.setVisible(true);
					nw.open(file);
					//nw.importProject();
					// nw.openNew(fi);
					nw.revalidate();
					nw.repaint();

				}

			} else {

				int n = JOptionPane.showConfirmDialog(null, "Environment : ["
						+ foldername
						+ "] already exist. Do you want to replace it?",
						"Ui Locator Editer - Question",
						JOptionPane.YES_NO_OPTION);
				if (n == 0) {
					File fi = null;
					File file = new File(parentPath + File.separator
							+ foldername);
					try {
						copyFile(parentDir, file);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//fi = new File(file.getAbsolutePath());

					/*
					 * System.out.println(fi.getAbsolutePath() + " " +
					 * tables.size()); XmlCreate.save(fi, tables, attrib);
					 */

					/*
					 * if (getExistingMainInstance().isActive()){
					 * getExistingMainInstance().setVisible(false); }
					 */

					NewIstancePanel nw = NewIstancePanel.getMainIns();
					nw.startUpInit();
					nw.open(file);
					nw.revalidate();
					nw.repaint();
					//nw.setVisible(true);
					// nw.openNew(fi);
					
				}

			}

		}
	}

	public void copyFile(File srcDir, File destDir){
		File[] fileList = srcDir.listFiles();
		 for (File srcFile: srcDir.listFiles()) {
			 srcFile.getAbsolutePath();
		        if (!srcFile.isDirectory()) {
		            try {
						FileUtils.copyFileToDirectory(srcFile, destDir);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
		    }


	}

	public NewEnviement(uiDesiner mainIns) {
		excistingMainInstance = mainIns;
	}

	private uiDesiner getExistingMainInstance() {
		return excistingMainInstance;

	}

}
