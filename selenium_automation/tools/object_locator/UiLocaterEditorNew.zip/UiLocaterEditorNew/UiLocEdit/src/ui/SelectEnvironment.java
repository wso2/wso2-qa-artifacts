package ui;

import java.awt.Dimension;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import domain.pages;

public class SelectEnvironment {
	
	private static uiDesiner excistingMainInstance;
	private static NewIstancePanel excistingNewInstance;
	 private static pages pg = new pages();

	public SelectEnvironment(String parentPath) {
		
		//getExistingMainInstance().isActive();
		
		File parentFile = new File(parentPath);
		File fileParent = parentFile.getParentFile();
		String pParentPath = fileParent.getAbsolutePath();
		File f = new File(parentPath);
		
		String[] envListStrings;
		File[] list = f.listFiles();
		
		
		envListStrings=fileNames(parentPath);
		
//		if (!getExistingMainInstance().isActive()) {
//		envListStrings=fileNames(pParentPath);
//		} else {
//			envListStrings=fileNames(parentPath);
//		}

		JComboBox templateList = new JComboBox(envListStrings);
		templateList.setPreferredSize(new Dimension(100, 25));
		
		//templateList.setSelectedIndex(0);
	
		
		templateList.setVisible(true);
		JLabel lab1 = new JLabel("Environment :", JLabel.LEFT);
		//JTextField envEnter = new JTextField("Enter Envirement here", 20);
		//envEnter.setVisible(true);
		templateList.setVisible(true);
		
		JPanel myPanel = new JPanel();

		//myPanel.add(templateList);
		myPanel.add(lab1);
		myPanel.add(templateList);
		
		int result = JOptionPane.showConfirmDialog(null, myPanel,
				"Select the prefered template", JOptionPane.OK_CANCEL_OPTION);
		if (result == JOptionPane.OK_OPTION) {
			try {
				uiDesiner.isclosed = true;
				//pg.repainTree();
				//uiDesiner.closeProject();;
			String foldername = templateList.getSelectedItem().toString();
			File theDir = new File(parentPath+ File.separator +foldername);
			
			//excistingNewInstance.setVisible(false);
			
			NewIstancePanel nw = NewIstancePanel.getMainIns();
		
			nw.startUpInit();
			//nw.setVisible(true);
			nw.open(theDir);
			//nw.importProject();
			// nw.openNew(fi);
			nw.revalidate();
			nw.repaint();
			
			//nw.open(theDir);
			
			} catch (NullPointerException e) {
				JOptionPane.showMessageDialog(null, "Please create New Environment", "Error", JOptionPane.ERROR_MESSAGE);
			}

			//File theDir = new File(parentPath+ File.separator +foldername+File.separator+ "DataTables.xml");
		//	excistingNewInstance.isActive();		
			/*NewIstancePanel nw = NewIstancePanel.getMainIns();
			nw.setVisible(true);
			
			nw.openNew(theDir);*/
			
			//XmlCreate.save(theDir, tables, attrib);
			/*if (!theDir.exists()) {
				System.out.println("creating directory: " + foldername);
				boolean result1 = false;

				try {
					theDir.mkdir();
					result1 = true;
				} catch (SecurityException se) {
					// handle it
				}
				if (result1) {
					System.out.println("DIR created");
					File fi = null;
					File file = new File(parentPath + File.separator
							+ foldername + File.separator + "DataTables.xml");

					fi = new File(file.getAbsolutePath());

					System.out.println(fi.getAbsolutePath() + " "
							+ tables.size());
					XmlCreate.save(fi, tables, attrib);
					// =========================================
					//getExistingMainInstance().setVisible(false);
					NewIstancePanel nw = new NewIstancePanel();
					nw.setVisible(true);
					
					nw.openNew(fi);
					// =======================================

				}

			} else {
				File fi = null;
				File file = new File(parentPath + File.separator + foldername
						+ File.separator + "DataTables.xml");

				fi = new File(file.getAbsolutePath());

				System.out.println(fi.getAbsolutePath() + " " + tables.size());
				XmlCreate.save(fi, tables, attrib);

				// =========================================

				//getExistingMainInstance().setVisible(false);
				//System.exit(0);
				NewIstancePanel nw = new NewIstancePanel();

				nw.setVisible(true);
				
				
				
				//System.out.println("CCCCCCCC");
				nw.openNew(fi);
				// =======================================
			}*/

		}
	}

	public SelectEnvironment(uiDesiner mainIns) {
		excistingMainInstance = mainIns;
	}
	
	
	private uiDesiner getExistingMainInstance(){
		return excistingMainInstance;
		
	}
	
	
	
	public static String[] fileNames(String directoryPath) {

	    File dir = new File(directoryPath);

	    Collection<String> files  =new ArrayList<String>();

	    if(dir.isDirectory()){
	        File[] listFiles = dir.listFiles();

	        for(File file : listFiles){
	            if(file.isDirectory()) {
	                files.add(file.getName());
	            }
	        }
	    }

	    return files.toArray(new String[]{});
	}

}
