package defaultMain;

import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;

import ui.*;

/*
 * author msmuttettuwa
 */

public class mainDev {

    public mainDev() {
       // uiDesiner.initializeUI();
        uiDesiner.startUpInit();
    }

    public static void main(final String[] args) {
        try {
            // Set cross-platform Java L&F (also called "Metal")
            // UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                } else {
                    UIManager.setLookAndFeel(UIManager
                            .getCrossPlatformLookAndFeelClassName());
                }
                // System.out.println(info.getName());
            }
        } catch (UnsupportedLookAndFeelException e) {
            System.out
                    .println("Error :- Unsupported Look And Feel Exception || "
                            + e);
        } catch (ClassNotFoundException e) {
            System.out.println("Error :- Class Not Found Exception || " + e);
        } catch (InstantiationException e) {
            System.out.println("Error :- Instantiation Exception || " + e);
        } catch (IllegalAccessException e) {
            System.out.println("Error :- Illegal Access Exception || " + e);
        }
        new mainDev();
    }

}
